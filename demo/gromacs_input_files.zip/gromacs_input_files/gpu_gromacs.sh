offset=64;
gpu_id=0;
ntomp=4;
ntmpi=4; # gputasks needs to have as many digits as ntmpi, ex.: if ntmpi=4, gputasks=0000
gputasks=0000;
# Minimization:

        gmx grompp -f step6.0_minimization.mdp -o step6.0_minimization.tpr -c step5_input.gro -r step5_input.gro -p topol.top
        gmx mdrun -v -deffnm step6.0_minimization -nb gpu -ntomp $ntomp -ntmpi $ntmpi -pin on -pinoffset $offset -gpu_id $gpu_id


# Equilibration:
        gmx grompp -f step6.1_equilibration.mdp -o step6.1_equilibration.tpr -c step6.0_minimization.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.1_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1
        gmx grompp -f step6.2_equilibration.mdp -o step6.2_equilibration.tpr -c step6.1_equilibration.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.2_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1
        gmx grompp -f step6.3_equilibration.mdp -o step6.3_equilibration.tpr -c step6.2_equilibration.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.3_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1
        gmx grompp -f step6.4_equilibration.mdp -o step6.4_equilibration.tpr -c step6.3_equilibration.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.4_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1
        gmx grompp -f step6.5_equilibration.mdp -o step6.5_equilibration.tpr -c step6.4_equilibration.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.5_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1
        gmx grompp -f step6.6_equilibration.mdp -o step6.6_equilibration.tpr -c step6.5_equilibration.gro -r step5_input.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step6.6_equilibration -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1

# Production
        gmx grompp -f step7_production.mdp -o step7_1.tpr -c step6.6_equilibration.gro -n index.ndx -p topol.top
        gmx mdrun -v -deffnm step7_1 -ntmpi $ntmpi -ntomp $ntomp -gputasks $gputasks -pin on -pinoffset $offset -nb gpu -nstlist 120 -pme gpu -npme 1

